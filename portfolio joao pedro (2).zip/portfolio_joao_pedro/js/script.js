// Efeito de entrada suave nas seções conforme a página é rolada.
document.addEventListener("DOMContentLoaded", () => {
  const elementos = document.querySelectorAll(
    ".info-card, .feature-card, .hobby-card, .goal-panel"
  );

  elementos.forEach((elemento) => {
    elemento.classList.add("reveal");
  });

  const observador = new IntersectionObserver((entradas) => {
    entradas.forEach((entrada) => {
      if (entrada.isIntersecting) {
        entrada.target.classList.add("visible");
        observador.unobserve(entrada.target);
      }
    });
  }, { threshold: 0.12 });

  elementos.forEach((elemento) => observador.observe(elemento));

  // Fecha o menu mobile depois de clicar em um link.
  document.querySelectorAll(".navbar-nav .nav-link").forEach((link) => {
    link.addEventListener("click", () => {
      const menu = document.querySelector("#menu");
      if (menu.classList.contains("show")) {
        bootstrap.Collapse.getOrCreateInstance(menu).hide();
      }
    });
  });
});
