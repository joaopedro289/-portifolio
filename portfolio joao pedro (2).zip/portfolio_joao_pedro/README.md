# Portfólio — João Pedro Lopes Araújo

Projeto acadêmico de portfólio pessoal, desenvolvido com HTML, CSS, JavaScript e Bootstrap 5.3.8.

## Estrutura
- `index.html`: conteúdo e estrutura das seções.
- `css/style.css`: identidade visual e responsividade.
- `js/script.js`: efeitos de entrada e comportamento do menu mobile.
- `img/`: imagens pessoais e de hobbies; os três jogos enviados estão em `img/hobbies/jogos/`.
- `bootstrap/`: arquivos locais do Bootstrap 5.3.8.

## Como visualizar
Abra o arquivo `index.html` no navegador. Para publicar no GitHub Pages, envie todos os arquivos mantendo a estrutura de pastas e habilite Pages para a branch principal, usando a raiz (`/`) como pasta.

## Personalizações pendentes
- Foto de perfil adicionada em `img/perfil/joao-pedro.jpeg`.
- Adicionar imagens próprias aos cards de hobbies, se desejar.
- Incluir links de contato/redes sociais caso queira divulgá-los.
- Revisar o texto e confirmar se todas as informações estão corretas.

- Foto de amigos e família adicionada em `img/hobbies/familia-amigos.png`.

- Foto da caixa de som adicionada em `img/hobbies/caixa-de-som.jfif`.

- Imagem de som automotivo aprimorada e utilizada no card Música: `img/hobbies/som-automotivo-melhorado.jpg`.

- Foto de perfil atualizada em `img/perfil/joao-pedro-atualizado.jpg`.
- Card `Passeio` criado; a foto do Nicolândia poderá ser adicionada em `img/hobbies/passeio-nicolandia.jpg`.

- Foto do Nicolândia aprimorada e adicionada ao card Passeio em `img/hobbies/passeio-nicolandia-melhorado.jpg`.


## Bootstrap
Este projeto utiliza Bootstrap 5.3.8 com os arquivos locais `bootstrap/css/bootstrap.min.css` e `bootstrap/js/bootstrap.bundle.min.js`. O CSS personalizado está em `css/style.css` e o JavaScript do projeto em `js/script.js`.
